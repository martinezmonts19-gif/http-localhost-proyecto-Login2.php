<?php
require('class.phpmailer.php');
require('class.smtp.php');

$mail = new PHPMailer();

$mail->IsSMTP();
$mail->Host = "smtp.gmail.com";
$mail->SMTPAuth = true;
$mail->Username = "montstulipanes@gmail.com"; // Tu correo Gmail
$mail->Password = "hfvt ldwf unij yfbq"; // Clave de aplicación, NO tu contraseña normal
$mail->SMTPSecure = "tls";
$mail->Port = 587;

$mail->From = "montstulipanes@gmail.com";
$mail->FromName = "Tienda de Tulipanes";
$mail->AddAddress("correo_destinatario@gmail.com", "Cliente de ejemplo");

$mail->Subject = "🌷 Prueba de envío de correo con PHP 5 y PHPMailer";
$mail->Body = "Hola! Este es un correo de prueba enviado desde WampServer y PHP 5 usando PHPMailer.";

if(!$mail->Send()) {
    echo "⚠️ Error al enviar correo: " . $mail->ErrorInfo;
} else {
    echo "✅ Correo enviado correctamente.";
}
?>
